﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Drawing.Printing;
using System.Drawing.Imaging;

namespace XL2IMG
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void PrintPanelContent()
        {
            PrintDocument pd = new PrintDocument();
            pd.DefaultPageSettings.Landscape = true; // Set landscape mode
            pd.PrintPage += new PrintPageEventHandler(PrintPanelPage);
            pd.Print();
        }

        private void XPrintPanelPage(object sender, PrintPageEventArgs e)
        {
            Bitmap bmp = new Bitmap(panel1.Width, panel1.Height);
            panel1.DrawToBitmap(bmp, new Rectangle(0, 0, panel1.Width, panel1.Height));
            e.Graphics.DrawImage(bmp, 0, 0);
        }
        private void PrintPanelPage(object sender, PrintPageEventArgs e)
        {
            // Calculate the dimensions for each quadrant
            int panelWidth = panel1.Width;
            int panelHeight = panel1.Height;
            int paperWidth = e.PageBounds.Width;
            int paperHeight = e.PageBounds.Height;
            int quadrantWidth = paperWidth / 2;
            int quadrantHeight = paperHeight / 2;

            // Draw the panel in each quadrant
            DrawControl(panel1, e.Graphics, new Rectangle(0, 0, quadrantWidth, quadrantHeight));
            DrawControl(panel1, e.Graphics, new Rectangle(quadrantWidth, 0, quadrantWidth, quadrantHeight));
            DrawControl(panel1, e.Graphics, new Rectangle(0, quadrantHeight, quadrantWidth, quadrantHeight));
            DrawControl(panel1, e.Graphics, new Rectangle(quadrantWidth, quadrantHeight, quadrantWidth, quadrantHeight));
        }

        private void DrawControl(Control control, Graphics graphics, Rectangle bounds)
        {
            Bitmap bitmap = new Bitmap(control.Width, control.Height);
            control.DrawToBitmap(bitmap, new Rectangle(0, 0, control.Width, control.Height));
            graphics.DrawImage(bitmap, bounds);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            PrintPanelContent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Bitmap bmp = new Bitmap(panel1.Width, panel1.Height);
            panel1.DrawToBitmap(bmp, new Rectangle(0, 0, panel1.Width, panel1.Height));
            bmp.Save(@"C:\Users\aa10180\Documents\XL2PDF\panel_image.png", ImageFormat.Png);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        // Call the PrintPanelContent function from a button click event or any other suitable event.
    }
}
